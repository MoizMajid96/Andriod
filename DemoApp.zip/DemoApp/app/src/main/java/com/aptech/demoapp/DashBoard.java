package com.aptech.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class DashBoard extends AppCompatActivity {

    private TextView show;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        show = findViewById(R.id.dataID);

        Intent RetriveData = getIntent();
        String MyData = RetriveData.getStringExtra("key");

        show.setText(MyData);

    }
}
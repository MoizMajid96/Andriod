package com.aptech.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    // Variables/Class Fields are defined here

    private EditText email, pass;
    private Button btn;

    // $_SESSION
    private SharedPreferences sharedPreferences;
    private String PrefName = "mypref";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Event Listener

        email = findViewById(R.id.emailID);
        pass = findViewById(R.id.passID);
        btn = findViewById(R.id.btnID);


        sharedPreferences = getSharedPreferences(PrefName, MODE_PRIVATE);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Email = email.getText().toString();
                String Password = pass.getText().toString();


                if(Email.equals("admin@gmail.com")){


                    // Creating SharedPrefrence

                    SharedPreferences.Editor edit = sharedPreferences.edit();
                    edit.putString("email", Email);
                    edit.commit();

                    // Header()
                    // Redirect()

                    // Source -> MainActivity
                    // Destination -> DashBoard.class

                    Intent nav = new Intent(MainActivity.this, DashBoard.class);
                    nav.putExtra("key", Email);
                    nav.putExtra("key2", Password);

                    startActivity(nav);
                }

            }
        });
    }

    public void onsubmit(View view) {
        String Email = email.getText().toString();
        Log.d("Check", "Email is :"+ Email);
    }

}
package com.aptech.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    // Variables/Class Fields are defined here

    private EditText email, pass;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Event Listener

        email = findViewById(R.id.emailID);
        pass = findViewById(R.id.passID);
        btn = findViewById(R.id.btnID);






        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Email = email.getText().toString();
                int Password = Integer.parseInt(pass.getText().toString());

                if(Email.equals("admin@gmail.com") && Password == 123){

                    // Header()
                    // Redirect()

                    // Source -> MainActivity
                    // Destination -> DashBoard.class

                    Intent nav = new Intent(MainActivity.this, DashBoard.class);
                    startActivity(nav);
                }

            }
        });
    }

    public void onsubmit(View view) {
        String Email = email.getText().toString();
        Log.d("Check", "Email is :"+ Email);
    }
}